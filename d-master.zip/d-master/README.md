Locale-Based Redirects

In order to better serve users who visit our sites, we use this simple PHP page to detect the locale, and direct them to the appropriate translation of a static website. If the language the user speaks isn't available, they automatically default to English, because the Anglo-Saxons took the world over.
